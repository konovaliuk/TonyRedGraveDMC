package ua.kpi.myhospital.Repo;

import org.springframework.data.repository.CrudRepository;
import ua.kpi.myhospital.Entities.Diagnos;

public interface DiagnosRepository extends CrudRepository<Diagnos, Integer> {

}
